# 🎨 IMPLEMENTAÇÃO COMPLETA: Logo da Agência + Logo de Clientes

## **O QUE VAI FUNCIONAR:**

✅ **Logo da Agência**
- Upload na página de Configurações
- Aparece no sidebar (sempre)
- Aparece no header (sempre)
- Aparece no portal público
- Pode ser customizada ou usar padrão

✅ **Logo de Clientes**
- Cada cliente tem sua própria logo
- Upload ao criar cliente
- Upload ao editar cliente (botão trocar)
- Aparece na lista de clientes
- Aparece no portal público do cliente

---

## **4 PASSOS (25 minutos)**

### **PASSO 1: Atualizar Logo.tsx (1 min)**

1. Abre `src/components/Logo.tsx`
2. Seleciona TUDO (Ctrl+A)
3. Deleta
4. Copia TUDO do arquivo `Logo-Updated.tsx`
5. Cola (Ctrl+V)
6. Salva (Ctrl+S)

**O que muda**: Agora aceita `customLogoUrl` e mostra a logo customizada da agência

---

### **PASSO 2: Atualizar Página Settings (2 min)**

1. Abre `src/app/agency/settings/page.tsx`
2. Seleciona TUDO (Ctrl+A)
3. Deleta
4. Copia TUDO do arquivo `settings-page.tsx`
5. Cola (Ctrl+V)
6. Salva (Ctrl+S)

**O que muda**: Agora tem upload de logo da agência com preview

---

### **PASSO 3: Atualizar Página Clientes (2 min)**

1. Abre `src/app/agency/clients/page.tsx`
2. Seleciona TUDO (Ctrl+A)
3. Deleta
4. Copia TUDO do arquivo `clients-page-final.tsx`
5. Cola (Ctrl+V)
6. Salva (Ctrl+S)

**O que muda**: Logo de cliente com upload integrado

---

### **PASSO 4: Testar Localmente (20 min)**

```bash
npm run dev
```

#### **Teste 1: Logo da Agência**
1. Va em **Configurações**
2. Procura por **"Logo da Agência"**
3. Clica na área cinza
4. Escolhe uma imagem
5. Vê o preview aparecer
6. Clica **"💾 Salvar Configurações"** ✅
7. Volta pro home
8. **A logo aparece no sidebar e header!** ✅

#### **Teste 2: Logo de Cliente**
1. Va em **Clientes**
2. Clica **"Novo cliente"**
3. Preenche nome
4. Clica na área cinza pra fazer upload de logo
5. Escolhe imagem
6. Vê o preview
7. Clica **"Criar"**
8. **Logo aparece na lista!** ✅

#### **Teste 3: Trocar Logo de Cliente**
1. Na lista de clientes
2. Clica em **"🔄 Trocar"** (ao lado da logo)
3. Escolhe nova imagem
4. **Logo atualiza instantaneamente!** ✅

#### **Teste 4: Portal Público**
1. Clica em **"🔗 Link"** (cliente)
2. Copia e abre em aba anônima
3. **Logo do cliente aparece no topo!** ✅

---

### **PASSO 5: Git Push (2 min)**

```bash
git add .
git commit -m "feat: add agency and client logo upload"
git push
```

---

### **PASSO 6: Redeploy Vercel (2 min)**

1. https://vercel.com
2. Projeto **agencia-ashen**
3. **Deployments**
4. Último deploy → 3 pontinhos → **Redeploy**
5. Aguarda ficar verde ✅

---

## **RESULTADO FINAL:**

### **Na Agência (Painel)**
```
┌─────────────────────────────┐
│  [LOGO] Deliver             │  ← Logo aparece aqui
│                              │
│  ✓ Overview                  │
│  ✓ Clientes                  │
│    ├─ [LOGO] Barbearia      │  ← Logo de cliente
│    └─ [LOGO] Odontologia    │  ← Logo de cliente
│  ✓ Demandas                  │
│  ✓ Configurações             │  ← Upload aqui
└─────────────────────────────┘
```

### **No Portal Público**
```
agencia-ashen.vercel.app/c/minha-agencia/cliente
┌─────────────────────────────┐
│  [LOGO CLIENTE]             │  ← Logo do cliente aqui
│  Nome do Cliente             │
│                              │
│  Projetos...                 │
└─────────────────────────────┘
```

---

## **RESUMO:**

| Feature | Onde Fica | Como Editar |
|---------|-----------|-------------|
| Logo da Agência | Sidebar + Header | Configurações → Logo da Agência |
| Logo de Cliente | Lista + Portal | Clientes → 📷 Logo / 🔄 Trocar |
| Receita Mensal | Lista de Clientes | Novo cliente ou editar |

---

**Tudo pronto!** Avisa quando terminar os 4 passos que a gente testa! 🚀
